
#include <iostream>
#include<vector>
#include<ctime> 
#include<cstdlib>

void reheapdown(std::vector<int>& v, int first, int last)
{
    int m, l, r;
    l = first * 2 + 1;
    r = first * 2 + 2;
    
    while (l <= last)
    {
        m = 1;
        if (r <= last && v[r]> v[l])
        {
            m = r;
        }

        if (v[first] < v[m]) {
            std::swap(v[first], v[m]);
            first = m;
            l = first * 2 + 1;
            r = first * 2 + 2;
           
        }
        else {
            break;
        }
    }
    




}
void hsort(std::vector<int>& v, int n) {
    for (int i = n / 2 - 1; i >= 0; --i)
    {
        reheapdown(v, i, v.size() - 1);

    }
    for (int i = n - 1; i > 0; --i) {
        std::swap(v[0], v[i]);
        reheapdown(v, 0, i - 1);
    }
}

void insertionSort(std::vector<int>& arr, int n)
{
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;

        // Move elements of arr[0..i-1],
        // that are greater than key, to one
        // position ahead of their
        // current position
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
int main()
{
    //Insert 100,000 values in ascending order (from 1 to 100,000), store values in A and E
    std::vector<int> A;
    std::vector<int> E;
    A.reserve(100000);
    E.reserve(100000);
    int i;
    for (i = 1; i <= 100000; ++i)
    {
        A.push_back(i);
        E.push_back(i);
    }
    //Insert 100, 000 values in descending order(from 100, 000 to 1), store values in B and F
    std::vector<int> B;
    std::vector<int> F;
    B.reserve(100000);
    F.reserve(100000);
    int j;
    for (j = 100000; j >= 1; --j)
    {
        B.push_back(j);
        F.push_back(j);

    }
    // Insert 100,000 random values2, store values in C and values^3 in G
    std::vector<int> C;
    std::vector<int> G;
    C.reserve(100000);
    G.reserve(100000);
    srand(time(0)); //seed
    int k;
    for (k = 1; k <= 100000; k++) {
        int v1 = rand();
        C.push_back(v1 * v1);
        G.push_back(v1 * v1 * v1);

    }
    // Implement heap sort for vector(STL)
   
    hsort(A, A.size());
    hsort(B, B.size());
    hsort(C, C.size());

    // Implement insertion sort for vector (STL)
    insertionSort(A, A.size());
    insertionSort(B, B.size());
    insertionSort(C, C.size());


    return 0;



}

