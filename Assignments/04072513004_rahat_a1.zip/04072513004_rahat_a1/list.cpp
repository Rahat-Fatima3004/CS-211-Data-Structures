#include <iostream>
#include<list>
#include<ctime> 
#include<cstdlib>
#include<chrono>
void Insertasc(std::list<int>& v) {
    int i;
    for (i = 1; i <= 100000; ++i)
    {
        v.push_back(i);

    }
}
void Insertdsc(std::list<int>& v) {
    int j;
    for (j = 100000; j >= 1; --j)
    {
        v.push_back(j);
    }
}
void Insertran(std::list<int>& v)
{
    srand(time(0)); //seed
    int k;
    for (k = 1; k <= 100000; k++) {
        int val = rand();
      
        v.push_back(val);

    }

}

int main()
{
    //Insert 100,000 values in ascending order (from 1 to 100,000), store values in A and E
    std::list<int> A;
    std::list<int> E;

    //A
    auto start1 = std::chrono::steady_clock::now();
    Insertasc(A);
    auto stop1 = std::chrono::steady_clock::now();
    auto duration1 = std::chrono::duration_cast<std::chrono::microseconds>(stop1 - start1);
    std::cout << "Time taken for Inserting 100,000 values in ascending order in A =  " << duration1.count() << std::endl;
    //E
    auto start2 = std::chrono::steady_clock::now();
    Insertasc(E);
    auto stop2 = std::chrono::steady_clock::now();
    auto duration2 = std::chrono::duration_cast<std::chrono::microseconds>(stop2 - start2);
    std::cout << "Time taken for Inserting 100,000 values in ascending order in E = " << duration2.count() << std::endl;

    //Insert 100, 000 values in descending order(from 100, 000 to 1), store values in B and F
    std::list<int> B;
    std::list<int> F;

    //B
    auto start3 = std::chrono::steady_clock::now();
    Insertdsc(A);
    auto stop3 = std::chrono::steady_clock::now();
    auto duration3 = std::chrono::duration_cast<std::chrono::microseconds>(stop3 - start3);
    std::cout << "Time taken for Inserting 100,000 values in descending order in B =  " << duration3.count() << std::endl;
    //F
    auto start4 = std::chrono::steady_clock::now();
    Insertdsc(F);
    auto stop4 = std::chrono::steady_clock::now();
    auto duration4 = std::chrono::duration_cast<std::chrono::microseconds>(stop4 - start4);
    std::cout << "Time taken for Inserting 100,000 values in descending order in F = " << duration4.count() << std::endl;

    // Insert 100,000 random values2, store values in C and values^3 in G
    std::list<int> C;
    std::list<int> G;

    //C
    auto start5 = std::chrono::steady_clock::now();
    Insertran(C);
    auto stop5 = std::chrono::steady_clock::now();
    auto duration5 = std::chrono::duration_cast<std::chrono::microseconds>(stop5 - start5);
    std::cout << "Time taken for Inserting 100,000 random values in C = " << duration5.count() << std::endl;
    //G
    auto start6 = std::chrono::steady_clock::now();
    Insertran(G);
    auto stop6 = std::chrono::steady_clock::now();
    auto duration6 = std::chrono::duration_cast<std::chrono::microseconds>(stop6 - start6);
    std::cout << "Time taken for Inserting 100,000 random values in G = " << duration6.count() << std::endl;

    //Sort the containers A-C using methods available in the STL (member function, if available, std::sort otherwise).
    //A
    auto start7 = std::chrono::steady_clock::now();
    A.sort();
    auto stop7 = std::chrono::steady_clock::now();
    auto duration7 = std::chrono::duration_cast<std::chrono::microseconds>(stop7 - start7);
    std::cout << "Time taken for sorting A = " << duration7.count() << std::endl;
    //B
    auto start8 = std::chrono::steady_clock::now();
    B.sort();
    auto stop8 = std::chrono::steady_clock::now();
    auto duration8 = std::chrono::duration_cast<std::chrono::microseconds>(stop8 - start8);
    std::cout << "Time taken for sorting B = " << duration8.count() << std::endl;
    //C
    auto start9 = std::chrono::steady_clock::now();
    C.sort();
    auto stop9 = std::chrono::steady_clock::now();
    auto duration9 = std::chrono::duration_cast<std::chrono::microseconds>(stop9 - start9);
    std::cout << "Time taken for sorting C = " << duration9.count() << std::endl;

    //Delete all the odd numbers from the containers E - G, use erase_if with lambda functions.
   //E
    auto start10 = std::chrono::steady_clock::now();
    std::erase_if(E, [](int n) {
        return n % 2 != 0;
        });
    auto stop10 = std::chrono::steady_clock::now();
    auto duration10 = std::chrono::duration_cast<std::chrono::microseconds>(stop10 - start10);
    std::cout << "Time taken deleting all the odd numbers from the container E" << duration10.count() << std::endl;

    //F
    auto start11 = std::chrono::steady_clock::now();
    std::erase_if(F, [](int n) {
        return n % 2 != 0;
        });
    auto stop11 = std::chrono::steady_clock::now();
    auto duration11 = std::chrono::duration_cast<std::chrono::microseconds>(stop11 - start11);
    std::cout << "Time taken deleting all the odd numbers from the container F" << duration11.count() << std::endl;

    //G
    auto start12 = std::chrono::steady_clock::now();
    std::erase_if(G, [](int n) {
        return n % 2 != 0;
        });
    auto stop12 = std::chrono::steady_clock::now();
    auto duration12 = std::chrono::duration_cast<std::chrono::microseconds>(stop12 - start12);
    std::cout << "Time taken deleting all the odd numbers from the container G" << duration12.count() << std::endl;


    return 0;



}



    
